#ifndef OPENFLOW_BSN_EXT_H
#define OPENFLOW_BSN_EXT_H 1

#include "openflow/openflow.h"
#include "openvswitch/types.h"

#define BSN_VENDOR_ID 0x005c16c7

/* Header for BSN vendor requests and replies. */
struct bsn_header {
    struct ofp_header header;
    ovs_be32 vendor;            /* BSN_VENDOR_ID. */
    ovs_be32 subtype;           /* See the BXT numbers in ofp-msgs.h. */
};
OFP_ASSERT(sizeof(struct bsn_header) == 16);

/* Array element for BXT_GET_INTERFACES_REPLY */
struct bsn_interface {
    uint8_t hw_addr[6];
    uint8_t pad[2];
    char name[16];
    uint32_t ipv4_addr;
    uint32_t ipv4_addr_mask;
};
OFP_ASSERT(sizeof(struct bsn_interface) == 32);

enum bsn_action_subtype {
    BSNAST_MIRROR = 1,               /* unimplemented */
    BSNAST_SET_TUNNEL_DST = 2,       /* struct bsn_action_set_tunnel_dst */
};

/* Header for BSN-defined actions. */
struct bsn_action_header {
    ovs_be16 type;                  /* OFPAT_VENDOR. */
    ovs_be16 len;                   /* Length is 16. */
    ovs_be32 vendor;                /* BSN_VENDOR_ID. */
    ovs_be32 subtype;               /* BSNAST_*. */
    uint8_t pad[4];
};
OFP_ASSERT(sizeof(struct bsn_action_header) == 16);

/* Action structure for BSNAST_SET_TUNNEL_DST.
 *
 * Sets the encapsulating tunnel destination IP. */
struct bsn_action_set_tunnel_dst {
    ovs_be16 type;                  /* OFPAT_VENDOR. */
    ovs_be16 len;                   /* Length is 16. */
    ovs_be32 vendor;                /* BSN_VENDOR_ID. */
    ovs_be32 subtype;               /* BSNAST_SET_TUNNEL_DST. */
    ovs_be32 tun_dst;               /* Destination IP. */
};
OFP_ASSERT(sizeof(struct bsn_action_set_tunnel_dst) == 16);

#endif
